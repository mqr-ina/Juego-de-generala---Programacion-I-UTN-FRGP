#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED

#include <time.h>
/* Usar en el main (si es un proyecto), o en el cpp para que compile.

#include<iostream>
#include<cstdlib>
#include<cstdio>
#include<ctime>

using namespace std;
#include �funciones.h�
*/
// Poner el archivo en la misma carpeta que el cpp
/// DECLARACI�N/PROTOTIPO DE FUNCIONES
void cargarVector(int v[], int tam);///asigna valores a cada una de las posiciones del vector

void mostrarVector(int v[], int tam);/// muestra lo que contiene cada una de las posiciones del vector

void ponerCero(int v[], int tam);/// pone en 0 todas las posiciones del vector

int posicionNumeroEnVector(int v[],int tam, int numero);/// devuelve la posici�n que ocupa un n�mero que se //env�a como par�metro. Devuelve la primera posici�n que encuentra el n�mero. Si no lo encuentra devuelve -1
int contarNumerosRepetidos(int v[], int numero, int tam);///cuenta la cantidad de veces que se repite un //n�mero en el vector

int maximoVector(int v[], int tam);///devuelve  la posici�n (primera) que ocupa el m�ximo en el vector

int minimoVector(int v[], int tam);///devuelve  la posici�n (primera) que ocupa el m�nimo en el vector


void cargarAleatorio(int v[], int tam, int limite);///asigna valores aleatorios a cada al vector

void ordenarVector(int v[], int tam );/// ordena de menor a mayor un vector

int compEscalera (int v[], int tam); /// comprueba si hay o no escalera en el vector

bool todosIguales (int v[], int tam); /// compara los valores de un vector si son iguales o no

bool compararSexteto (int v[], int tam); //compara los valores en busca de un sexteto

int sumarVector(int v[], int tam ); /// suma los valores contenidos en el vector

void copiarVector(int v[], int v2[],int tam ); ///copia el vector v en v2

bool compararVectores(int v[], int v2[],int tam );// compara los dos vectores que recibe. Si son iguales ///devuelve true, si no devuelve false





#endif // FUNCIONES_H_INCLUDED
